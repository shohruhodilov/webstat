from django.db import models


class Qurilish(models.Model):
    q_type = models.CharField(max_length=100)
    servise_name = models.CharField(max_length=100)
    servise_code = models.CharField(max_length=5)
    soato = models.CharField(max_length=6)
    report_month = models.CharField(max_length=6)
    report_year = models.CharField(max_length=6)
    last_year = models.CharField(max_length=6)

    def __str__(self):
        return self.q_type


# Create your models here.
