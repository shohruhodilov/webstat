from django.shortcuts import render,HttpResponseRedirect
from django.views.generic import CreateView

from .models import Qurilish


class Qurilish_view(CreateView):
    model = Qurilish
    fields = ['q_type', 'servise_name', 'servise_code', 'soato', 'report_month', 'report_year', 'last_year']
    template_name = 'app/home.html'
    context_object_name = 'qurilishs'
    success_url = '/'

    def form_valid(self, form):
        self.object = form.save()
        # do something with self.object
        # remember the import: from django.http import HttpResponseRedirect
        return HttpResponseRedirect(self.get_success_url())