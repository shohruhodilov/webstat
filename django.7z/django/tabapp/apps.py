from django.apps import AppConfig


class TabappConfig(AppConfig):
    name = 'tabapp'
