from django. forms import ModelForm
from .models import Qurilish


class QurilishForm(ModelForm):
    class Meta:
        model = Qurilish
        fields = ['q_type', 'servise_name', 'servise_code', 'soato', 'report_month', 'report_year', 'last_year']