from django.contrib import admin
from .models import Qurilish


admin.site.register(Qurilish)



